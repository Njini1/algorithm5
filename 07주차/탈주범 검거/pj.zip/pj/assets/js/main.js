function getCity() {
  let city = document.querySelector('.dropdown-menu');
  console.log(city);
}
